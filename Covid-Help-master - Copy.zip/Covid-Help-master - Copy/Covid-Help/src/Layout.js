import {Grid,Row,Col,Image} from 'react-bootstrap';
import React,{Component} from 'react';
import {Panel} from 'react-bootstrap';
import CovidNavigationPanel from './panels/CovidNavigationPanel';

class Layout extends Component{
    constructor(){
        super();
        this.onSelectAlert = this.onSelectAlert.bind(this);
    }
    onSelectAlert(eventKey){
        this.setState({navSubTitle:eventKey});   
    }
    dynamicContent(){
        return(<table width="100%">
                <tbody>
                    <tr >
                        <td >
                            <Panel>
                                <Panel.Body>                                  
                                    <CovidNavigationPanel/>
                                </Panel.Body>
                            </Panel>
                        </td>
                    </tr>
                </tbody>
            </table>
                );
        
    }
    render(){
        return(this.dynamicContent());
    }
}
export default (Layout);