import React, {Component} from 'react';
import Tabs from 'react-bootstrap/lib/Tabs';
import Tab from 'react-bootstrap/lib/Tab';
import CountryHelplinePanel from '../panels/CountryHelpLinePanel';
class HelplineTabC extends Component{
    
    constructor(props){
        super(props)
    }
    componentDidMount() {
        
     }
    componentDidUpdate() {
        
     }

    dynamicContent(){
        return <div>           
            <Tabs id="covid-tab-id">
                <Tab eventKey="countryhelpline" title="Country Helpline">
                    <CountryHelplinePanel/>
                </Tab>
                <Tab eventKey="admin" title="Administrative Service">
                    
                </Tab>
                <Tab eventKey="sos" title="Emergency/SOS" >
                    
                </Tab>
            </Tabs>                
        </div>
     }
     render() {
        return (this.dynamicContent());
     }
}
export default HelplineTabC