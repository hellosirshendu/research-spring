import React, {Component} from 'react';
import {BootstrapTable,TableHeaderColumn} from 'react-bootstrap-table';

class GridC extends Component{
     
    constructor(props){
        super(props)
    }
    componentDidMount() {
        
    }
   componentDidUpdate() {
       
    }
    
   dynamicContent(){
       if(this.props.isHelpLine){
        return <div>
                    <BootstrapTable data={ this.props.data } options={ this.props.options } width='100%' height='100%' bordered={false} striped hover condensed>
                        <TableHeaderColumn dataField='country' dataSort >Country</TableHeaderColumn>
                        <TableHeaderColumn dataField='state' filter={ { type: 'TextFilter', delay: 1000 } } dataSort>State</TableHeaderColumn>
                        <TableHeaderColumn dataField='helpLineNumber' isKey dataSort>HelpLine number</TableHeaderColumn>
                    </BootstrapTable>
                </div>
       }else if(this.props.isServiceSearch){
        return <div>
                    <BootstrapTable data={ this.props.data } options={ this.props.options } width='100%' height='100%' bordered={false} striped hover condensed>
                        <TableHeaderColumn dataField='organisationname' isKey dataSort filter={ { type: 'TextFilter', delay: 1000 } }>Organisation Name</TableHeaderColumn>
                        <TableHeaderColumn dataField='typeofservice' filter={ { type: 'TextFilter', delay: 1000 } } dataSort>Organization Type</TableHeaderColumn>
                        <TableHeaderColumn dataField='address'  dataSort>Address</TableHeaderColumn>
                        <TableHeaderColumn dataField='contact'  dataSort>Contact</TableHeaderColumn>
                        <TableHeaderColumn dataField='desc'  dataSort>Description</TableHeaderColumn>
                        <TableHeaderColumn dataField='loc'  dataSort>Location</TableHeaderColumn>
                    </BootstrapTable>
                </div>
       }
       
    }
     render() {
        return (this.dynamicContent());
     }
}
export default GridC