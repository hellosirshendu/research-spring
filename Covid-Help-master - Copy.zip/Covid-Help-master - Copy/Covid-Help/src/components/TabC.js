import React, {Component} from 'react';
import Tabs from 'react-bootstrap/lib/Tabs';
import Tab from 'react-bootstrap/lib/Tab';
import HelplineTabC from './HelplineTabC';
import ServiceRegistartionPanel from '../panels/ServiceRegistrationPanel';
import ServiceSearchPanel from '../panels/ServiceSearchPanel';

class TabC extends Component{
    
    constructor(props){
        super(props)
    }
    componentDidMount() {
        
     }
    componentDidUpdate() {
        
     }

    dynamicContent(){
        return <div>           
            <Tabs id="covid-tab-id">
                <Tab eventKey="helpline" title="Helpline">
                    <HelplineTabC/>
                </Tab>
                <Tab eventKey="register" title="Service Registration">
                    <ServiceRegistartionPanel/>
                </Tab>
                <Tab eventKey="search" title="Service Search" >
                    <ServiceSearchPanel/>
                </Tab>
            </Tabs>                
        </div>
     }
     render() {
        return (this.dynamicContent());
     }
}
export default TabC