import React, {Component} from 'react';
import {Panel,Glyphicon,DropdownButton,MenuItem, Image} from 'react-bootstrap';
import {Grid,Row,Col} from 'react-bootstrap';
import email from '../images/email-16.png';
import refresh from '../images/refresh-16.png';
import setting from '../images/setting-16.png';
import search from '../images/icons8-search-16.png';
import projectmapping from '../../../ProjectMapping.json';
import {Form,FormControl} from 'react-bootstrap';

function onSelectAlert(job) {
    alert(`Alert from menu item.\neventKey: ${job}`);
  }
//function settingClick() {
  //  alert(`Alert from setting:`);
 // }
  function emailClick() {
    alert(`Alert from email:`);
  }
  //function refreshClick() {
 //   alert(`Alert from refresh:`);
 // }

class NavigationC extends Component{
    
    constructor(props){
        super(props);
        this.state={navSubTitle:this.props.subtitle};
    }
    componentDidMount() {
        this.props.inputRef(this)
     }
    componentDidUpdate() {
        
     }
    
     selectToolMappingData(){
         switch(this.props.type){
            case "jenkins":
                return projectmapping.jenkins.projectmapping
                break;
            case "sonar":
                return projectmapping.sonar.projectmapping
                break;
            default:
            break;
         }
     }

     populateDropDownWithMapping(items){
        let data = this.props.data;
        let filter = this.props.filter;
        
        console.log('data:'+data);
        for (let i = 0; i <= data.length - 1; i++) {                                                  
            console.log('data[i].label:'+data[i].label);              
            items.push(<MenuItem eventKey={data[i].label} onSelect={this.props.onCountryclick} id={i} key={i}>{data[i].label}</MenuItem>);                
            }                                   
								
        return items;
     }

     populateDropDown() {
        let items = [];   
        let data = this.props.data;
        let filter = this.props.filter;
       if(data != undefined){           
            this.populateDropDownWithMapping(items);                               
        }
        return items;
    }
   callBackMethod(title){
       this.setState({navSubTitle:title});
   }
   
   checkForCountryDropDown(countryNA){
    if(countryNA){
        return (<td width = "25%">&nbsp;</td>); 
     }
    else{
        return ( <td ><b><font size='2'>{this.props.countryField}</font></b>&nbsp;
                    <DropdownButton                             
                        title={this.state.navSubTitle}
                        id="1" align="right">
                    {this.populateDropDown()}
                    </DropdownButton>
                </td>);           
        }
    
   }
   checkForOrgName(orgnameNA){
    if(orgnameNA){
        return (<td width = "25%">&nbsp;</td>); 
     }
    else{
        return ( <td >
                    <Form inline>
                    <b><font size='2'>{this.props.orgField}</font></b>&nbsp;
                
                    <FormControl
                        type="text"
                        placeholder="Enter Org name"
                        id="orgnameSearch"
                    />
                    
                    <b><font size='2'>{this.props.orgtypeField}</font></b>&nbsp;
                    
                    <FormControl componentClass="select" placeholder="select" id="orgtypeSearch">
                            <option value="select">select</option>
                            <option value="Grocery">Grocery shop</option>
                            <option value="Medical">Medical Shop</option>
                            <option value="Food_distribution">Food Distribution</option>
                        </FormControl>
                        </Form>
                </td>);           
        }
    
   }
    dynamicContent(){
        return <div> 
                <Panel>   
                    <Panel.Body>       
                        <table width = "100%">
                                <tbody>
                                    <tr width = "100%">
                                        <td width = "5%" align="left"><b><font size='4'>{this.props.title}</font></b></td>                                                                                       
                                        <td valign="right"> {this.checkForCountryDropDown(this.props.countryNA)}  </td> 
                                        <td valign="right"> {this.checkForOrgName(this.props.orgnameNA)}  </td>                                                                             
                                        <td width = "20%"/>
                                        <td width = "5%"> <Image src={search}  onClick={this.props.onSearchclick} align = "right" title="Search"/>  </td>
                                        <td width = "5%"> <Image src={email}  onClick={emailClick} align = "center" title="Send Email"/>  </td>
                                        <td width = "5%"> <Image src={refresh} rounded onClick={this.props.onRefresh} align = "center" title="Refresh data"/></td>
                                        <td width = "5%"> <Image src={setting} rounded onClick={this.props.onSetting} align = "left" title="Search setting"/></td>
                                    </tr>
                                </tbody>
                            </table>
                       </Panel.Body>
                    </Panel>             
                 </div>
     }
     render() {
        return (this.dynamicContent());
     }
}
export default NavigationC