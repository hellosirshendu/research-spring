import axios from 'axios';
import projectmapping from '../../../ProjectMapping.json';

export const REQUEST_SEARCH = 'REQUEST_SEARCH'
export const HELPLINE_FILTER = 'HELPLINE_FILTER'
export const SERVICE_REGISTER = 'SERVICE_REGISTER'
export const SERVICE_SEARCH = 'SERVICE_SEARCH'


function requestSearch() {
    return {
      type: REQUEST_SEARCH
    }
  }
 
function responseFilterHelplineData(json) {
  return {
    type: HELPLINE_FILTER,
    data: json
  }
}
function errorSearch(json) {
	return {
		type: 'ERROR',
		data: json
	}
}
function responseServiceRegistration(json) {
  return {
    type: SERVICE_REGISTER,
    data: json
  }
}
function errorServiceSave(json) {
	return {
		type: 'ERROR',
		data: json
	}
}
function responseServiceSearch(json) {
  return {
    type: SERVICE_SEARCH,
    data: json
  }
}
var axiosConfig = {
    auth: {
        username: 'admin',
        password: 'admin'
      },
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
        
    }
  };
  var axiosCommonConfig = {
   
    headers: {
        
        "Access-Control-Allow-Origin": "http://localhost:3000"
    }
  };

export function filterHelplineData(country) {
    return dispatch => {
      
        return axios.get(projectmapping.covid.serverURL+'countryHelpLineNumber/'+country,axiosConfig)
                    .then(function(response) {
                      dispatch(responseFilterHelplineData(response));
                    })
                    .catch(function(response){
                      dispatch(errorSearch(response));				
                    })
    }
  }
    export function serviceRegistration(service) {
      return dispatch => {
          console.log("Invoke POst");
          console.log(service);
          return axios.post(projectmapping.covid.serverURL+'serviceRegistrationForm',service,axiosConfig)
                      .then(function(response) {
                        dispatch(responseServiceRegistration(response));
                      })
                      .catch(function(response){
                        dispatch(errorServiceSave(response));				
                      })
      }
    }
      export function serviceSearch(orgname,orgtype) {
        return dispatch => {
            console.log("Invoke search");
            console.log(orgname);
            console.log(orgtype);
            return axios.get(projectmapping.covid.serverURL+'searchServiceOffering/'+orgname+'/'+orgtype,axiosConfig)
                        .then(function(response) {
                          dispatch(responseServiceSearch(response));
                        })
                        .catch(function(response){
                          dispatch(errorServiceSave(response));				
                        })
        }
    } 