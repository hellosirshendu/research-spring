import React,{Component} from 'react';
import {Panel} from 'react-bootstrap';
import GridC from '../components/GridC';
import FormC from '../components/FormC';
import BuildSettingPanel from '../modal/BuildSettingPanel';
import { connect } from 'react-redux';
import {filterHelplineData} from '../actions/index';

class ServiceRegistrationPanel extends Component{
    navDropDowndata = [{label: 'India'},{label: 'United States Of America'},{label: 'Italy'},{label: 'ALL'}]   
    navSubTitle = "ALL";
    constructor(){
        super();
        this.nameFormatter = this.nameFormatter.bind(this);
        this.onCountrySelect = this.onCountrySelect.bind(this);
        this.onSearchClick = this.onSearchClick.bind(this);       
        this.state={navSubTitle:'Select Country'}
    }
    onCountrySelect(eventKey){
        this.setState({navSubTitle:eventKey});
        this.nav.callBackMethod(eventKey);
    }
    onSearchClick(eventKey){
        const { dispatch } = this.props;    
        dispatch(filterHelplineData(this.state.navSubTitle));
    }
    render(){
        return (
            <Panel>               
                <Panel.Body> 
                    <table width="100%">
                        <tbody>
                        <tr>
                            <td>
                                <u><b><p align="left"></p></b></u>
                            </td> 
                        </tr>
                        <tr>
                            <td  width="100%">
                                <FormC/>
                            </td> 
                        </tr>
                    </tbody>
                    </table>
                 </Panel.Body>
            </Panel>
        );
    }
    options = {
        onRowClick: function(row) {
          alert(`You click row number: ${row.status}`);
        },
        onRowDoubleClick: function(row) {
          alert(`You double click row number: ${row.status}`);
        }
      };
    nameFormatter(cell) {                          
        if(cell == 'Released'){            
            return '<p><font color=\'green\'>'+cell+'</p>';
         }
         if(cell == 'Staged'){            
             return '<p><font color=\'red\'>'+cell+'</p>';
         }     
    }
}
function createBarChartDetailData(obj){
    console.log(obj);
    return obj;
}
function mapStateToProps(state){ 
    
    return {
        gridData:createBarChartDetailData(state.filterHelplineData.data)
    };
  }
export default connect(mapStateToProps) (ServiceRegistrationPanel);