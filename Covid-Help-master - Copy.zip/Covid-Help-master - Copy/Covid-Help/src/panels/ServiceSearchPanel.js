import React,{Component} from 'react';
import {Panel} from 'react-bootstrap';
import GridC from '../components/GridC';
import NavigationC from '../components/NavigationC';
import BuildSettingPanel from '../modal/BuildSettingPanel';
import { connect } from 'react-redux';
import {serviceSearch} from '../actions/index';

class ServiceSearchPanel extends Component{
    navDropDowndata = [{label: 'India'},{label: 'United States Of America'},{label: 'Italy'},{label: 'ALL'}]   
    navSubTitle = "ALL";
    constructor(){
        super();
        this.nameFormatter = this.nameFormatter.bind(this);
        this.onCountrySelect = this.onCountrySelect.bind(this);
        this.onSearchClick = this.onSearchClick.bind(this);       
        this.state={navSubTitle:'Select Country'}
    }
    onCountrySelect(eventKey){
        this.setState({navSubTitle:eventKey});
        this.nav.callBackMethod(eventKey);
    }
    onSearchClick(eventKey){
        const { dispatch } = this.props;    
        dispatch(serviceSearch(document.getElementById("orgnameSearch").value,document.getElementById("orgtypeSearch").value));
    }
    render(){
        return (
            <Panel>               
                <NavigationC title={"Search"} countryNA={true}  orgField={"Organization Name"} orgtypeField={"Organization Type"} inputRef={ref => (this.nav = ref)} subtitle={this.state.navSubTitle} data = {this.navDropDowndata} onCountryclick={this.onCountrySelect} onSearchclick={this.onSearchClick}/>
                <Panel.Body> 
                    <table width="100%">
                        <tbody>
                        <tr>
                            <td>
                                <u><b><p align="left">Service DETAILs</p></b></u>
                            </td> 
                        </tr>
                        <tr>
                            <td  width="100%">
                                <GridC  data={this.props.gridData}  options={this.options} isServiceSearch = {true}/>
                            </td> 
                        </tr>
                        <tr>
                            <td  width="100%">
                            <div id="mapDiv">
                                    <iframe id= "myFrame"  width="450"   height="250"  frameborder="0" 
                                            src="https://www.google.com/maps/embed/v1/search?key=AIzaSyCPHOaXIcMUTrP3uhh6ekv7NHVoZvwTIqw&q=medical+stores+in22.6061°+N,c&maptype=satellite&zoom=15" 
                                            >
                                    </iframe>
                                </div>
                            </td> 
                        </tr>
                    </tbody>
                    </table>
                    <BuildSettingPanel inputRef={ref => (this.buildSetting = ref)} submitform = {this.saveForm}/>                   
                </Panel.Body>
            </Panel>
        );
    }
    options = {
        onRowClick: function(row) {
          // alert(`You click row number: ${row.loc}`);
          var loca =   row.loc;
          var str_array = loca.split(',');
          var str_array2;
          
          for(var i = 0; i < str_array.length; i++) {
             // Trim the excess whitespace.
             var str1 = str_array[i];
             str_array2 = str1.split('°');
             for(var j = 0; j < str_array2.length; j++) {
                str_array2[j] = str_array2[j].replace(/^\s*/, "").replace(/\s*$/, "");    
             }
             str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
             str_array[i] = str_array2[0] + '°+' + str_array2[1];
            }
                   
          var finalLoc = str_array[0] + "+" + str_array[1];
         // alert("finalLoc " +finalLoc);
          var loc= "https://www.google.com/maps/embed/v1/search?key=AIzaSyCPHOaXIcMUTrP3uhh6ekv7NHVoZvwTIqw&q=" + finalLoc+"&zoom=15"
         // alert("loc " +loc);
          document.getElementById('myFrame').setAttribute('src', loc);
          
        },
        onRowDoubleClick: function(row) {
         // alert(`You double click row number: ${row.loc}`);
        }
      };
    nameFormatter(cell) {                          
        if(cell == 'Released'){            
            return '<p><font color=\'green\'>'+cell+'</p>';
         }
         if(cell == 'Staged'){            
             return '<p><font color=\'red\'>'+cell+'</p>';
         }     
    }
}
function createBarChartDetailData(obj){
    console.log(obj.data);
    return obj.data;
}
function mapStateToProps(state){ 
    
    return {
        gridData:createBarChartDetailData(state.serviceSearch.data)
    };
  }
export default connect(mapStateToProps) (ServiceSearchPanel);