import React,{Component} from 'react';
import {Panel} from 'react-bootstrap';
import TabC from '../components/TabC';

class CovidNavigationPanel extends Component{
    
    constructor(){
        super();
    }
    render(){
        return (
            <Panel>               
               <Panel.Body> 
                    <table width="100%">
                        <tbody>
                        <tr>                           
                            <td >
                                <u><b><p align="left">COVID-19 Help</p></b></u>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <font size = "2"> <i><p  align="left">COVID-19 affects different people in different ways. Most infected people will develop mild to moderate symptoms.</p></i>
                            </font>
                            </td>                         
                        </tr>
                        <tr>
                            <td>
                            <font size = "2" color="red">
                                <p  align="left">Common symptoms:
                                <ul align="left">
                                    <li align="left" >fever</li>
                                    <li align="left" >tiredness</li>
                                    <li align="left" >dry cough</li>
                                </ul>
                                </p>
                            </font>
                            </td>                         
                        </tr>
                        <tr>
                            <td  width="100%">                             
                                <TabC/>                           
                            </td>                          
                        </tr>                       
                    </tbody>
                    </table>                                      
                </Panel.Body>
            </Panel>
        );
    }
    
}
export default (CovidNavigationPanel);