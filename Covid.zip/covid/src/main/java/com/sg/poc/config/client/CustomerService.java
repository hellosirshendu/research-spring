package com.sg.poc.config.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@RefreshScope
@Service
public class CustomerService {


	/*
	 * @Autowired CustomAppData customAppData;
	 */

	@Autowired

	@Qualifier("engConfig")
	CustomAppData englishConfig;

	@Autowired

	@Qualifier("polandConfig")
	CustomAppData polandConfig;

	@Autowired

	@Qualifier("frenchConfig")
	CustomAppData frenchConfig;

	@Autowired
	private ApplicationContext applicationContext;

	public String insertCustomer() {
		String applanguage = System.getProperty("app-language");
		System.out.println("applanguage :" + applanguage);

		/*
		 * CustomAppData customAppData =
		 * applicationContext.getBean(CustomAppData.class);
		 * System.out.println("Values  : \n DatSource :: " +
		 * customAppData.getDatsource());
		 */

		if (applanguage.equalsIgnoreCase("en"))
			System.out.println("English Values  : \n DatSource :: " + englishConfig.getDatsource() + "  DB Name :: "
					+ englishConfig.getDbname());
		else if (applanguage.equalsIgnoreCase("pl"))
			System.out.println("Poland Values  : \n DatSource :: " + polandConfig.getDatsource() + "\n DB Name :: "
					+ polandConfig.getDbname());
		else if (applanguage.equalsIgnoreCase("fr"))
			System.out.println("French Values  : \n DatSource :: " + frenchConfig.getDatsource() + "\n DB Name :: "
					+ frenchConfig.getDbname());

		return "Ke Jane Ki Value";
	}

}