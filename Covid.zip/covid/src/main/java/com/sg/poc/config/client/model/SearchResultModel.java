package com.sg.poc.config.client.model;

public class SearchResultModel {

	String organisationname;
	String typeofservice;
	String address;
	String contact;
	String desc;
	String loc;

	public String getOrganisationname() {
		return organisationname;
	}

	public void setOrganisationname(String organisationname) {
		this.organisationname = organisationname;
	}

	public String getTypeofservice() {
		return typeofservice;
	}

	public void setTypeofservice(String typeofservice) {
		this.typeofservice = typeofservice;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

}
