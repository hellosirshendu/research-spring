package com.sg.poc.config.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CustomAppData /* implements ApplicationContextAware */ {

	//@Value("${fr.datsource}")
	private String datsource;

	//@Value("${fr.dbname}")
	 private String dbname;

	/*
	 * private String applicationId;
	 * 
	 * public void setApplicationContext(ApplicationContext applicationContext)
	 * throws BeansException { applicationId = applicationContext.getId(); }
	 * 
	 * public String getApplicationId() { return applicationId; }
	 */

	public String getDatsource() {
		return datsource;
	}

	public void setDatsource(String datsource) {
		this.datsource = datsource;
	}

	public String getDbname() {
		return dbname;
	}

	public void setDbname(String dbname) {
		this.dbname = dbname;
	}

	@Override
	public String toString() {
		return "CustomAppData [datsource=" + datsource + ", dbname=" + dbname /* + ", applicationId=" + applicationId */
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((datsource == null) ? 0 : datsource.hashCode());
		result = prime * result + ((dbname == null) ? 0 : dbname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomAppData other = (CustomAppData) obj;
		if (datsource == null) {
			if (other.datsource != null)
				return false;
		} else if (!datsource.equals(other.datsource))
			return false;
		if (dbname == null) {
			if (other.dbname != null)
				return false;
		} else if (!dbname.equals(other.dbname))
			return false;
		return true;
	}
	
	


}
