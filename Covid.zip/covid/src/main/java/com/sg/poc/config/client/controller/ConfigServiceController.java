package com.sg.poc.config.client.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sg.poc.config.client.model.CountryHelpLineModel;
import com.sg.poc.config.client.model.HelpineNumberModel;
import com.sg.poc.config.client.model.SearchResultModel;

@RefreshScope
@RestController
public class ConfigServiceController {

	@RequestMapping(value = "/countryHelplineNumber", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> getCountryHelplineNumber(@RequestParam String country) {

		List<CountryHelpLineModel> rtrnList = new ArrayList<CountryHelpLineModel>();
		CountryHelpLineModel obj1 = new CountryHelpLineModel();
		obj1.setCountry("India");
		obj1.setHelpLineNumber("100");
		obj1.setState("WB");

		CountryHelpLineModel obj11 = new CountryHelpLineModel();
		obj11.setCountry("India");
		obj11.setHelpLineNumber("100");
		obj11.setState("DL");

		CountryHelpLineModel obj2 = new CountryHelpLineModel();
		obj2.setCountry("USA");
		obj2.setHelpLineNumber("911");
		obj2.setState("CO");

		CountryHelpLineModel obj22 = new CountryHelpLineModel();
		obj22.setCountry("USA");
		obj22.setHelpLineNumber("911");
		obj22.setState("NJ");

		if ("India".equalsIgnoreCase(country)) {
			rtrnList.add(obj1);
			rtrnList.add(obj11);
		} else if ("USA".equalsIgnoreCase(country)) {
			rtrnList.add(obj2);
			rtrnList.add(obj22);
		}

		return new ResponseEntity<Object>(rtrnList, HttpStatus.OK);
	}

	@RequestMapping(value = "/healthcareHelplineNumber", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> getHealthcareHelplineNumber(@RequestParam String country,
			@RequestParam String state) {

		List<HelpineNumberModel> rtrnList = new ArrayList<HelpineNumberModel>();
		HelpineNumberModel obj1 = new HelpineNumberModel();
		obj1.setName("Kolkata Medical College");
		obj1.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj1.setPhnumber("88888888");
		;

		HelpineNumberModel obj11 = new HelpineNumberModel();
		obj11.setName("New Delhi Medical College");
		obj11.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj11.setPhnumber("88888888");

		HelpineNumberModel obj111 = new HelpineNumberModel();
		obj111.setName("CO College");
		obj111.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj111.setPhnumber("11111111");

		HelpineNumberModel obj1111 = new HelpineNumberModel();
		obj1111.setName("NJ College");
		obj1111.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj1111.setPhnumber("88888888");

		if ("India".equalsIgnoreCase(country)) {
			if ("WB".equalsIgnoreCase(state))
				rtrnList.add(obj1);
			else if ("Delhi".equalsIgnoreCase(state))
				rtrnList.add(obj11);
		} else if ("USA".equalsIgnoreCase(country)) {
			if ("CO".equalsIgnoreCase(state))
				rtrnList.add(obj111);
			else if ("NJ".equalsIgnoreCase(state))
				rtrnList.add(obj1111);
		}

		return new ResponseEntity<Object>(rtrnList, HttpStatus.OK);
	}

	@RequestMapping(value = "/adminHelplineNumber", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Object> getAdminHelplineNumber(@RequestParam String country, @RequestParam String state) {

		List<HelpineNumberModel> rtrnList = new ArrayList<HelpineNumberModel>();
		HelpineNumberModel obj1 = new HelpineNumberModel();
		obj1.setName("Kolkata Medical College");
		obj1.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj1.setPhnumber("88888888");
		;

		HelpineNumberModel obj11 = new HelpineNumberModel();
		obj11.setName("New Delhi Medical College");
		obj11.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj11.setPhnumber("88888888");

		HelpineNumberModel obj111 = new HelpineNumberModel();
		obj111.setName("CO College");
		obj111.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj111.setPhnumber("11111111");

		HelpineNumberModel obj1111 = new HelpineNumberModel();
		obj1111.setName("NJ College");
		obj1111.setAddress(
				"It is a big value.\n It is a big value. \n It is a big value. \\n It is a big value.\n It is a big value.");
		obj1111.setPhnumber("88888888");

		if ("India".equalsIgnoreCase(country)) {
			if ("WB".equalsIgnoreCase(state))
				rtrnList.add(obj1);
			else if ("Delhi".equalsIgnoreCase(state))
				rtrnList.add(obj11);
		} else if ("USA".equalsIgnoreCase(country)) {
			if ("CO".equalsIgnoreCase(state))
				rtrnList.add(obj111);
			else if ("NJ".equalsIgnoreCase(state))
				rtrnList.add(obj1111);
		}

		return new ResponseEntity<Object>(rtrnList, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchServiceOffering", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<Object> getsearchServiceOffering(@RequestParam String organisationname,
			@RequestParam String typeofservice) {

		List<SearchResultModel> rtrnList = new ArrayList<SearchResultModel>();
		SearchResultModel obj1 = new SearchResultModel();
		obj1.setAddress(
				"It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.");
		obj1.setContact("111111111");
		obj1.setDesc(
				"Short Desc. Big Data. Short Desc. Big Data.. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data.");
		obj1.setLoc("22.5726° N, 88.3639° E");
		obj1.setOrganisationname("ORG Name1");
		obj1.setTypeofservice("Typeofservice1");

		SearchResultModel obj11 = new SearchResultModel();
		obj11.setAddress(
				"It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.");
		obj11.setContact("111111111");
		obj11.setDesc(
				"Short Desc. Big Data. Short Desc. Big Data.. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data.");
		obj11.setLoc("22.5726° N, 88.3639° E");
		obj11.setOrganisationname("ORG Name11");
		obj11.setTypeofservice("Typeofservice11");

		SearchResultModel obj111 = new SearchResultModel();
		obj11.setAddress(
				"It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.");
		obj111.setContact("111111111");
		obj111.setDesc(
				"Short Desc. Big Data. Short Desc. Big Data.. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data.");
		obj111.setLoc("22.5726° N, 88.3639° E");
		obj111.setOrganisationname("ORG Name111");
		obj111.setTypeofservice("Typeofservice111");

		SearchResultModel obj1111 = new SearchResultModel();
		obj111.setAddress(
				"It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.It IS adress. It is a big Data.");
		obj1111.setContact("111111111");
		obj1111.setDesc(
				"Short Desc. Big Data. Short Desc. Big Data.. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data. Short Desc. Big Data.");
		obj1111.setLoc("22.5726° N, 88.3639° E");
		obj1111.setOrganisationname("ORG Name1111");
		obj1111.setTypeofservice("Typeofservice1111");
		
		if ("ORG Name1".equalsIgnoreCase(organisationname))
			rtrnList.add(obj1);
		else if ("ORG Name11".equalsIgnoreCase(organisationname))
			rtrnList.add(obj11);
		else if ("ORG Name111".equalsIgnoreCase(organisationname))
			rtrnList.add(obj111);
		else if ("ORG Name1111".equalsIgnoreCase(organisationname))
			rtrnList.add(obj1111);
		
		if ("Typeofservice1".equalsIgnoreCase(typeofservice))
			rtrnList.add(obj1);
		else if ("Typeofservice11".equalsIgnoreCase(organisationname))
			rtrnList.add(obj11);
		else if ("Typeofservice111".equalsIgnoreCase(organisationname))
			rtrnList.add(obj111);
		else if ("Typeofservice1111".equalsIgnoreCase(organisationname))
			rtrnList.add(obj1111);

		return new ResponseEntity<Object>(rtrnList, HttpStatus.OK);
	}

}
