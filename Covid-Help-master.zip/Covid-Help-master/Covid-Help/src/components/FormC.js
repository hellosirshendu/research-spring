import React, {Component} from 'react';
import {Form,FormControl,FormGroup,ControlLabel,Col,Button} from 'react-bootstrap';
import { connect } from 'react-redux';
import {serviceRegistration} from '../actions/index';
class FormC extends Component{
    value = "";
    constructor(props){
        super(props)
        this.onClick = this.onClick.bind(this);
        this.state={status:"success"}
    }
    componentDidMount() {
        
     }
    componentDidUpdate() {
        
     }
     onClick(){
         
         var data = "{\"organisationname\":\""+document.getElementById("orgname").value+"\","+
         "\"typeofservice\":\""+document.getElementById("orgtype").value+"\","+
         "\"address\":\""+document.getElementById("address").value+"\","+
         "\"contact\":\""+document.getElementById("contact").value+"\","+
         "\"desc\":\""+document.getElementById("desc").value+"\","+
         "\"loc\":\""+document.getElementById("loc").value+"\""+
         "}";
         const { dispatch } = this.props;    
         dispatch(serviceRegistration(data));
         alert("Registration Done!! ");
     }

    dynamicContent(){
        return <div>           
            <Form horizontal >
                <FormGroup >
                    <Col componentClass={ControlLabel} sm={2}>
                        Organization Name
                    </Col>
                    <Col sm={10}>
                        <FormControl type="text" placeholder="Enter text" id ="orgname"/>
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} sm={2}>
                        Organization Type
                    </Col>
                    <Col sm={10}>
                        <FormControl componentClass="select" placeholder="select" id="orgtype">
                            <option value="select">select</option>
                            <option value="Grocery">Grocery shop</option>
                            <option value="Medical">Medical Shop</option>
                            <option value="Food_distribution">Food Distribution</option>
                        </FormControl>
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} sm={2}>
                        Address
                    </Col>
                    <Col sm={10}>
                        <FormControl componentClass="textarea" placeholder="Address" id="address" />
                    </Col>
                </FormGroup>
                <FormGroup  >
                    <Col componentClass={ControlLabel} sm={2}>
                        Contact Number
                    </Col>
                    <Col sm={10}>
                        <FormControl type="text" placeholder="Enter phone number" id ="contact"/>
                    </Col>
                </FormGroup>
                <FormGroup  >
                    <Col componentClass={ControlLabel} sm={2}>
                        Description of Organization
                    </Col>
                    <Col sm={10}>
                        <FormControl componentClass="textarea" placeholder="Some info about organization" id ="desc"/>
                    </Col>
                </FormGroup>
                <FormGroup  >
                    <Col componentClass={ControlLabel} sm={2}>
                        Latitude & Longitude
                    </Col>
                    <Col sm={10}>
                        <FormControl type="text" placeholder="Enter location Latitude & Longitude" id ="loc"/>
                    </Col>
                </FormGroup>
               
            </Form>    
            <Button type={"submit"} onClick={this.onClick}>Save</Button>           
        </div>
     }
     render() {
        return (this.dynamicContent());
     }
}
function mapStateToProps(state){ 
    return {
        status:state.serviceRegistration.data.status
    };
  }
export default connect(mapStateToProps)  (FormC);