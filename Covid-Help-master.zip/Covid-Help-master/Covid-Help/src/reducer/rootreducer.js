import { combineReducers } from 'redux';
import {HELPLINE_FILTER,REQUEST_SEARCH,SERVICE_REGISTER,SERVICE_SEARCH} from '../actions/index.js';


function filterHelplineData(state={data:[]},action){
    switch(action.type){
        case REQUEST_SEARCH:
            return state
        case HELPLINE_FILTER:
            return Object.assign({},state,{data:action.data})
        default:
            return state
    }
}
function serviceRegistration(state={data:[]},action){
    switch(action.type){
        case SERVICE_REGISTER:
            return Object.assign({},state,{data:action.data})
        default:
            return state
    }
}
function serviceSearch(state={data:[]},action){
    switch(action.type){
        case SERVICE_SEARCH:
            return Object.assign({},state,{data:action.data})
        default:
            return state
    }
}
const rootreducer = combineReducers({filterHelplineData,serviceRegistration,serviceSearch})
export default rootreducer